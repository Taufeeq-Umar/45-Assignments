"use strict";
// Store examples of bicycles in an array
let byCycle = ["Motercycle ", "Audi Car ", "Civic Car "];
//Print statements about the bicycles and cars
for (let i = 0; i < byCycle.length; i++) {
    console.log("I would like to own a " + byCycle[i] + ".");
}
