"use strict";
let myName = "\t \n   Taufeeq   \t\n";
// Print the name with whitespace
console.log("myName:", myName);
// Strip the whitespace around the name
let MyName = myName.trim();
// Print the stripped name
console.log("MyName:", MyName);
