"use strict";
// Store the names of your friends in an array called names
let Names = ["Muzamil ", "Amir ", "Taha ", "Hassan ", "Javed "];
// Print each person's name by accessing each element in the list one at a time
for (let i = 0; i < Names.length; i++) {
    console.log("Friend ", +(i + 1) + ":" + Names[i] + "! Have a good Day");
}
