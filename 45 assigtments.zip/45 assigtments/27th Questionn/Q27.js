"use strict";
let aliencolor = 'green';
if (aliencolor === 'green') {
    console.log("Player earned 5 points!");
}
else if (aliencolor === 'yellow') {
    console.log("Player earned 10 points!");
}
else if (aliencolor === 'red') {
    console.log("Player earned 15 points!");
}
let aleien_color = 'yellow';
if (aleien_color === 'green') {
    console.log("Player earned 5 points!");
}
else if (aleien_color === 'yellow') {
    console.log("Player earned 10 points!");
}
else if (aleien_color === 'red') {
    console.log("Player earned 15 points!");
}
const alien_color = 'red';
if (alien_color === 'green') {
    console.log("Player earned 5 points!");
}
else if (alien_color === 'yellow') {
    console.log("Player earned 10 points!");
}
else if (alien_color === 'red') {
    console.log("Player earned 15 points!");
}
