// Store the list of people to invite to dinner
let Guests : string[] = [" Malik Muzamil " , " Muhammad Farhat " , " Javed Sahil"];

// Print an invitation message to each person

for (let i = 0 ; i < Guests.length ; i++) {
    console.log("Dear Brother" + Guests[i] + ",\n\nYou are cordially invited to dinner. It would be an honor to have you join us.\n\nBest regards,\n[Taufeeq Umar]");
    
}


// Print the name of the guest who can't make it
let guestCantMakeIt: string = "Javed Sahil";
console.log("\nUnfortunately, " + guestCantMakeIt + " can't make it to dinner.\n");

// Replace the name of the guest who can't make it with a new guest
let newGuest: string = "Hassan Ali";
let indexOfGuestCantMakeIt: number = Guests.indexOf(guestCantMakeIt);
if (indexOfGuestCantMakeIt !== -1) {
    Guests[indexOfGuestCantMakeIt] = newGuest;
}

// Print a second set of invitation messages with the updated guest list
console.log("Updated invitation messages:");
for (let i = 0; i < Guests.length; i++) {
    console.log("Dear brother " + Guests[i] + ",\n\nYou are cordially invited to dinner. It would be an honor to have you join us.\n\nBest regards,\n[Taufeeq Umar]");
}
