// Array of famous rivers
let rivers: string[] = ["Jahlam", "Amazon", "Ravi", "5nand", "Sindh", "Satlaj", "Indus"];

// Print the list of rivers
console.log("List of famous rivers I would like to visit:");
rivers.forEach(river => {
    console.log(river);
});

