console.log(5 + 3); //Addition 8

console.log(10 - 2); // Subtraction

console.log(4 * 2); // Multiplication

console.log(16 / 2 ); // Division

