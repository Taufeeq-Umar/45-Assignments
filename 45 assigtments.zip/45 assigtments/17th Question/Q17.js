// Initial list of guests
let initialGuests = ["Muzamil", "Amir", "Taha", "Noman", "Farhat", "Raza"];
// Print the original invitation messages
initialGuests.forEach(guest => {
    console.log(`Dear ${guest}, you are invited to dinner.`);
});
// Inform that only two people can be invited
console.log("\nSorry, but we can only invite two people for dinner.");
// Remove guests from the list until only two names remain
while (initialGuests.length > 2) {
    const removedGuest = initialGuests.pop();
    console.log(`Sorry ${removedGuest}, but we can't invite you to dinner.`);
}
// Print messages to the remaining two people
initialGuests.forEach(guest => {
    console.log(`Dear ${guest}, you're still invited to dinner.`);
});
// Remove the last two names from the list
initialGuests.length = 0;
// Confirm that the list is empty
console.log("Final guest list:Muzamil , Amir", initialGuests);
export {};
