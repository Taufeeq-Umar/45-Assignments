// Array containing three favorite pizza names
const pizzas: string[] = ['Pepperoni', 'Margherita', 'BBQ Chicken'];

// Loop through the array to print each pizza name
for (const pizza of pizzas) {
    // Print a simple statement about each pizza
    console.log(`I like ${pizza} pizza.`);
}

// Print a closing statement
console.log("Pizza is one of my favorite foods. I really love pizza!");
