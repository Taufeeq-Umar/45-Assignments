"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
let personName = "Taufeeq";
console.log('Hello  $ {Taufeeq},would you like to learn some typescript today?');
