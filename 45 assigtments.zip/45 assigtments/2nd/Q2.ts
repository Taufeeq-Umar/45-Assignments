import { log } from "console";

let personName = "Taufeeq";

console.log('Hello  $ {Taufeeq},would you like to learn some typescript today?');
