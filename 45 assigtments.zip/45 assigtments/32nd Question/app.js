"use strict";
// List of current usernames
const currentUsers = ['John', 'Alice', 'Eric', 'Sophia', 'Michael'];
// List of new usernames
const newUsers = ['Alice', 'Peter', 'JOhn', 'Emily', 'David'];
// Convert currentUsers to lowercase for case-insensitive comparison
const currentUsersLower = currentUsers.map(user => user.toLowerCase());
// Loop through newUsers to check for uniqueness
for (const user of newUsers) {
    if (currentUsersLower.includes(user.toLowerCase())) {
        console.log(`The username '${user}' is not available. Please enter a new username.`);
    }
    else {
        console.log(`The username '${user}' is available.`);
    }
}
