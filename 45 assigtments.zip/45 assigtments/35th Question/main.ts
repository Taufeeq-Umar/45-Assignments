// Array containing names of three different animals
const animals: string[] = ['Dog', 'Cat', 'Rabbit'];

// Loop through the array to print each animal name
for (const animal of animals) {
    // Print a statement about each animal
    console.log(`A ${animal.toLowerCase()} would make a great pet.`);
}

// Print a statement about what these animals have in common
console.log("Any of these animals would make a great pet!");
