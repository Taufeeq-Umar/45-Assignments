// Creating an array
let myArray: number[] = [12,13,1417,22];

// Intentionally accessing an out-of-range index
try {
    console.log(myArray[10]); // Index 10 is out of range for this array
} catch (error) {
    console.error("Index error occurred. Fixing it...");
}


// Outputting the entire array to ensure everything is correct
console.log(myArray);

// Correcting the error by accessing a valid index
console.log(myArray[2]); // Accessing index 2