"use strict";
function show_magicians(magicians) {
    magicians.forEach(magician => console.log(magician));
}
function make_great(magicians) {
    return magicians.map(magician => "the Great " + magician);
}
let magician_names = ["David Copperfield", "Harry Houdini", "Penn Jillette", "Teller", "Derren Brown"];
let great_magician_names = make_great([...magician_names]);
console.log("Original Magicians:");
show_magicians(magician_names);
console.log("\nMagicians with 'the Great' added:");
show_magicians(great_magician_names);
