let Guest : string []= ["Muzamil ", "Amir " , "Hassan " , "Javed"];
console.log("Great news ! I found a bigger dinner Table !");

// adding more guets 
Guest.unshift("Raza");
Guest.splice(Guest.length /2 , 0 , "Mubashir");
Guest.push("Bakht Ali");

Guest.forEach(Guest => {
    console.log(`Dear ${Guest},would you like  to join me for a dinner?`);
    
});
