// Define some example items
const laptop = {
    brand: "Lenovo",
    model: "XPS 13",
    price: 22000
};



const fruitBasket = {
    fruits: ["apple", "banana", "orange"],
    quantity: 12,
    isOrganic: true
};

// Create an object to store these items
const storage: {[key: string]: any} = {
    laptop: laptop,
    fruitBasket: fruitBasket
};

// Access and display items stored in the object
console.log("Laptop:", storage.laptop);
console.log("Fruit Basket:", storage.fruitBasket);
