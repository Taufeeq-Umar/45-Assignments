"use strict";
// Store your favorite number in a variable
let myFavNumber = 12;
// Create a message revealing your favorite number
let message = `This is My Favourite number ${myFavNumber}.`;
// Print the message
console.log(message);
