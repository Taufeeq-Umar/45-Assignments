let Guests = ["Taufeeq ", "Muzamil ", "Farhat ", "Javed ", "Raza ", "Hassan "];
console.log(`I am inviting ${Guests.length}People to dinner.`);
export {};
