"use strict";
function makeSandwich(...items) {
    console.log("Sandwich summary:");
    if (items.length === 0) {
        console.log("No items selected for the sandwich.");
    }
    else {
        console.log("Items:");
        items.forEach(item => console.log("- " + item));
    }
    console.log("Enjoy your sandwich!\n");
}
// Call the function three times with different numbers of arguments
makeSandwich("Ham", "Cheese", "Lettuce", "Tomato");
makeSandwich("Turkey", "Swiss Cheese");
makeSandwich("Peanut Butter", "Jelly");
