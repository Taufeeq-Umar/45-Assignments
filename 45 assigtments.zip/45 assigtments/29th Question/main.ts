// Array of favorite fruits
let favoriteFruits: string[] = ['Apple', 'Banana', 'Mango'];

// Check for certain fruits in the array
if (favoriteFruits.includes('Apple')) {
    console.log("You really like Apples!");
}
if (favoriteFruits.includes('Banana')) {
    console.log("You really like Bananas!");
}
if (favoriteFruits.includes('Orange')) {
    console.log("You really like Oranges!");
}
if (favoriteFruits.includes('Mango')) {
    console.log("You really like Mangoes!");
}
if (favoriteFruits.includes('Strawberry')) {
    console.log("You really like Strawberries!");
}
