// Tests for equality and inequality with strings
console.log("hello" === "hello"); // true


// Tests using the lower case function
console.log("Hello".toLowerCase() === "hello".toLowerCase()); // true

// Numerical tests
console.log(5 === 5); // truee
console.log(10 > 5); // true
console.log(5 >= 10); // false
console.log(10 >= 5); // true
console.log(5 > 10); // false

// Tests using "and" and "or" operators
console.log(5 > 0 && 5 < 10); // true
console.log(15 < 10 || 15 > 20); // false

// Test whether an item is in an array
console.log([1, 2, 3, 4, 5].includes(3)); // true
console.log([1, 2, 3, 4, 5].includes(6)); // false

// Test whether an item is not in an array
console.log(![1, 2, 3, 4, 5].includes(6)); // true
console.log(![1, 2, 3, 4, 5].includes(3)); // false
