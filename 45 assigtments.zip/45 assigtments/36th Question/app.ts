function makeShirt(size: string, message: string): void {
    console.log(`The shirt size is ${size.toUpperCase()} and the message printed on it is: "${message}".`);
}

// Call the function with size "medium" and message "Hello, World!"
makeShirt("medium", "Hello, World!");
