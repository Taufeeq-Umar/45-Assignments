"use strict";
let personName = '';
let lowercase = personName.toLowerCase();
let uppercase = personName.toUpperCase();
let Titlecase = personName.split(' ').map(word => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
{
    alert(`Hello ${personName}, Here are your name in:
    lowerCase: ${lowercase}
    upperCase: ${uppercase}
    titleCase: ${Titlecase}`);
}
{
    alert('Please fill your name !');
}
