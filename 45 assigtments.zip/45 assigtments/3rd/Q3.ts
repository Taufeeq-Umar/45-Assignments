let personName :string = '';

let lowercase :string = personName .toLowerCase() ;
let uppercase :string = personName .toUpperCase() ;
let Titlecase :string = personName .split(' '). map(word =>word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ')

{
    alert(`Hello ${personName}, Here are your name in:
    lowerCase: ${lowercase}
    upperCase: ${uppercase}
    titleCase: ${Titlecase}`)
}
else{
    alert('Please fill your name !')
}