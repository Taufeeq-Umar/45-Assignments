let famousPersonName : string = "Albert Einstine";
let Message : string = ' $(Albert Einstine)  once saide, "A person who never made a mistake  never tried anything new."';
console.log(famousPersonName);
console.log(Message);
