"use strict";
let famousPersonName = "Albert Einstine";
let Message = ' $(Albert Einstine)  once saide, "A person who never made a mistake  never tried anything new."';
console.log(famousPersonName);
console.log(Message);
