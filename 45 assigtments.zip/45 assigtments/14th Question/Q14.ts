// Store the list of people to invite to dinner
let Guests : string[] = [" Malik Muzamil " , " Muhammad Farhat " , " Javed Sahil"];

// Print an invitation message to each person

for (let i = 0 ; i < Guests.length ; i++) {
    console.log("Dear Brother" + Guests[i] + ",\n\nYou are cordially invited to dinner. It would be an honor to have you join us.\n\nBest regards,\n[Taufeeq Umar]");
    
}




