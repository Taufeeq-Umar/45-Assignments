const usernames: string[] = ['Admin', 'Eric', 'John', 'Alice', 'Sophia'];

for (const username of usernames) {
    let greeting: string;

    if (username.toLowerCase() === 'Admin') {
        greeting = "Hello Admin, would you like to see a status report?";
    } else {
        greeting = `Hello ${username}, Thank you for logging in again.`;
    }

    console.log(greeting);
}
