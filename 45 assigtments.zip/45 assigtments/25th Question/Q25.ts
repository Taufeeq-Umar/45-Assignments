let aliencolor = "red";
if (aliencolor == "red"){
    console.log("you just earned 5 points");

}

aliencolor = "green"
if (aliencolor == "red"){
    console.log("you just earned 5 points"); // no out put
}