function storeCarInfo(manufacturer: string, modelName: string, ...additionalInfo: { [key: string]: any }[]): { manufacturer: string, modelName: string, [key: string]: any } {
    const carInfo: { manufacturer: string, modelName: string, [key: string]: any } = {
        manufacturer: manufacturer,
        modelName: modelName
    };

    additionalInfo.forEach(info => {
        const key = Object.keys(info)[0];
        carInfo[key] = info[key];
    });

    return carInfo;
}

// Call the function with required information and additional name-value pairs
const car = storeCarInfo("Toyota", "Camry", { color: "blue" }, { year: 2022 });

// Print the object returned to ensure all information was stored correctly
console.log(car);
