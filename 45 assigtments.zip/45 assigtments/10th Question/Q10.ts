// MY Name 29-03-2024
let myNmae : string = "Taufeeq Umar";
console.log(myNmae);

// My Education  29-03-2024
let myEducationn : string = "Intermediate" 
console.log(myEducationn);
