"use strict";
// MY Name 29-03-2024
let myNmae = "Taufeeq Umar";
console.log(myNmae);
// My Education  29-03-2024
let myEducationn = "Intermediate";
console.log(myEducationn);
