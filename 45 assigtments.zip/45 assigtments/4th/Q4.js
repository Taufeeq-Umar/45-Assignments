"use strict";
console.log('Albert Einstine once said,"A Person who never made a mistake never tried anything new"');
