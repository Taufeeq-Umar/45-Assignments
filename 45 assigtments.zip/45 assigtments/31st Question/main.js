"use strict";
let usernames = []; // Empty array initially
// Check if the array is empty
if (usernames.length === 0) {
    console.log("We need to find some users!");
}
else {
    // Loop through the array if it's not empty
    for (const username of usernames) {
        const greeting = username.toLowerCase() === 'admin' ?
            "Hello admin, would you like to see a status report?" :
            `Hello ${username}, thank you for logging in again.`;
        console.log(greeting);
    }
}
