function show_magicians(magicians: string[]): void {
    magicians.forEach(magician => {
        console.log(magician);
    });
}

// Array of magician's names
const magician_names: string[] = ["David Copperfield", "Harry Houdini", "Penn Jillette", "Teller", "Derren Brown"];

// Passing the array to the function
show_magicians(magician_names);

