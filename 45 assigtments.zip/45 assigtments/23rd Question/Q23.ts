let x = 10;
let y = 12;
let myName = "Taufeeq"
let car = "Cevic"
let bike = "Honda"

console.log(x == y); // false 

console.log(x == 10); // true

console.log(myName == bike); // false

console.log(car == `Cevic`); // true

console.log(car != `Cevic`); // false 

console.log(x != y); // true

console.log(myName == `Taufeeq`); // true

console.log(car != bike); // true

console.log(myName != `Taufeeq`); // false

console.log(bike != `Honda`);  // false
